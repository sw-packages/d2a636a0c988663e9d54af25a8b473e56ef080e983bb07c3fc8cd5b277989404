#ifndef _FONTCONFIG_SRC_FCSTDINT_H
#define _FONTCONFIG_SRC_FCSTDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "fontconfig 2.13.0"
/* generated using gnu compiler gcc (GCC) 7.3.1 20180130 (Red Hat 7.3.1-2) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
